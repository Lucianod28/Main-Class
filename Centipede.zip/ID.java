/**
 * ID.java organizes the ideas of all the GameObjects.
 * @version 6/21/16
 * @author Jonathan Shen
 */

public enum ID{
   Mushroom(),
   Missile(),
   Shooter(),
   Centipede();
}